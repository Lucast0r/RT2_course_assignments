#! /usr/bin/env python3

import rospy
import actionlib
import actionlib_msgs
import assignment_2_2022.msg
from my_package.srv import target, targetResponse


## @file service.py
# The service node has to return the number of goals reached / cancelled. To do so, if analyses the state of the robot. The states of the robots can be obtained by subscribing to this topic : /reaching_goal/result Here are the different states of the robot :
#
#   0 Robot is going to a point
#   1 Robot is following a wall
#   2 Goal has been cancelled
#   3 Goal has been reached
#
# By counting the number of times the state changes to either 2 and 3, we get the number of goals reached / cancelled. Then, it returns this data when it is called. That way we can print those values on the client terminal.
# 
# Service used 'service' ( when called, sends the number of goals reached / cancelled )
# Subscriber on topic "/reaching_goal/result"
#
# Author: Lucas Gigondan
# Version: 1.0
# Date: 06/05/2023



## Method result
#
# This function checks the status of the robot, and then updates the values of goals reached / cancelled depending on the robot status.  

def result(msg):
    # Check the status of the robot 
    status=msg.status.status
    # If status is 2, it means that a goal has been cancelled 
    if status == 2: 
        goal.cancelled += 1
    # Status  = 3 means that a goal has been reached.
    elif status == 3: 
        goal.reached += 1

## Method goal_callback.
#
# This function prints the number of goals reached and cancelled.
def goal_callback(req):
    # Print the number of goals in this window but also return it to the client that called this service node. 
    print ("Number of goals reached:", goal.reached )
    print ("Number of goals cancelled:", goal.cancelled )
    return goal


def main():
    # Set the goal as a global variable so it can be used in every function
    global goal

    # Set up goal with the correct service structure defined in /srv/target.srv
    goal = targetResponse()

    # Init the node 
    rospy.init_node('service')
    # Set up the service with the service structure and call a goal_callback when triggered.
    srv= rospy.Service('service', target, goal_callback)

    # Subscriber to this topic to get the state of the robot.
    # Based on the state, we will be able to know how many goals were reached or cancelled 
    subscriber_result = rospy.Subscriber('/reaching_goal/result', assignment_2_2022.msg.PlanningActionResult, result)
    rospy.spin()

if __name__ == "__main__":
    main()

