#!/usr/bin/env python3

import rospy
import actionlib
import actionlib_msgs
import assignment_2_2022.msg
from nav_msgs.msg import Odometry
from my_package.msg import output_client 
from my_package.srv import target 
from geometry_msgs.msg import Twist, Pose, Point
import sys
import select




## @mainpage My Python Package
#
#   Lucas Gigondan's solution to the second assignment of research track 1
#
#   Class : Research Track 1
# 
#   Professor : Carmine Tommaso Recchiuto
# 
#   Year : 2022-2023
# 
#   Student : Lucas Gigondan
# 
#   Student ID : s5646676
#
#
# How to run the code ? 
# 
#    First, clone this repository in the src folder of your ros workspace. This github repository contains two ros packages :
#        assignment_2_2022 (the base of our work published by our professor) Be carefull to take my version because I did a slight modification in the launch file.
#        my-package : my solution to this assignment with the three required nodes.
# 
#    If you haven't setup your workspace yet you can follow this tutorial : http://wiki.ros.org/catkin/Tutorials/create_a_workspace
# 
#    Then you will need to build the ros package you just cloned. To do so, run this command : 'catkin_make' (in the root directory of your workspace)
# 
#   Then you can launch the different nodes with this command : 'roslaunch assignment_2_2022 assignment1.launch'
# 
#   If it is working correctly, two terminal (client and distance), rviz and gazebo should open.
# Every file is explained on it's own. 
#
#
# Possible upgrades
#
#   Create a possibility to update the frequency at which informations are printed in the 'distance' node while the robot is moving / active.
#
#   Developping a better user interface could create a better user experience. Right now the code is not really comprehensive : if you type 'Service' instead of 'service' it will just output an error. It would be easier if you could call the service node by clicking a button.
#
#   Make the robot faster by changing his speeds but also the way he handles an obstacle.
#
#   Print more informations to the logs for example the service node could also register the positions of the reached / cancelled goals : For example :
#
#3 Goals reached :
#
#   [1,1]
#  [7,5]
# [-6,-2]
#
# 2 Goals cancelled :
#
#   [4,-3]
#   [1,2]
#
# This could even allow in the future to draw a map to show all the movements the robot did. Imagine this robot in a warehouse, moving pallets around to different locations. This map could help you optimize the shipping / storing process.
#
# If anything is unclear, feel free to contact me : lucas.gigondan@gmail.com


## @file client.py
# The client has a first job : get the user input goal for the robot. To do so, it opens a window asking the user for a 'x' and 'y' value. Once this value are entered, the node checks that they are actually float numbers. If they are of type float, the node will send this goal to the server.
#
# The second job is to publish data on a specific topic. The data to publish are :
#
#    velocity in X
#    velocity in Y
#    position in X
#    position in Y To find those values, the node will be subscribed to the /odom topic. Here the code is fairly simple : get the information from /odom and publish it back on /robot_position. To be published in /robot_position correctly, we defined a special msg structure : output_client.
#
# The third job of the node is to call the service node. If needed, the user can input 'user' and not a float number. In this case the service node is called.
#
# Service used 'service' ( waits for it and then prints out the numbers of goals reached )
# Publisher on topic "/robot_position"
# Subscriber on topic "odom"
# Action client on topic "reaching_goal"
#
# Author: Lucas Gigondan
# Version: 1.0
# Date: 06/05/2023


## Method call_service.
#
# This function calls the service node if the user input is 'service'
# It then prints out the goals reached and goals cancelled once it has the answer from the service node. 


def call_service ():
    
    # Wait for the node to respond
    rospy.wait_for_service('service')
    service = rospy.ServiceProxy('service', target)
    # Call the service
    response = service()
    # Print the number of goals reached and cancelled
    print("Goals reached: ", response.reached)
    print("Goals cancelled: ", response.cancelled)



## Method publish_infos.
#
# This function is used to publish the informations position and velocity

def publish_infos (msg):
        global pub 
        # Set Output with the custom msg structure 
        Output = output_client() 
        # Get position 
        position = msg.pose.pose.position 
        # Get twist 
        velocity = msg.twist.twist.linear 

        #Set the different parmaeters inside Output with the coresponding value. 
        Output.position_x = position.x
        Output.position_y = position.y
        Output.vel_x = velocity.x
        Output.vel_y = velocity.y

        # Publish the message on the topic
        pub.publish(Output) 


## Method client. 
#
# When a goal is reached, this method allows the user to input a new goal. 
# It will also check if the usre wants to cancel the goal. 

def client():

        # Initialize the action client
        client = actionlib.SimpleActionClient("reaching_goal", assignment_2_2022.msg.PlanningAction)
        # Wait for the server to be started
        client.wait_for_server()
        # initialize x and y (those are the user input)
        x = 0
        y = 0
        # This loop will run as long as rospy is running
        while not rospy.is_shutdown():
            # Get the input from user 
            # Input has to be a float or 'service'
            print ("Enter 'service' to access the service node ")
            x = input("Enter a goal x: ")
            y = input("Enter a goal y: ")

            
            if (x == "service") or (y == "service"):
                call_service() 
            else : 
                try : 
                    # Check if x and y are valid float values. 
                    x = float (x)
                    y = float (y)

                except ValueError:#  More detailed description of the Robot class.
                    # If an error is raised, print this message.
                    print (" Error, input was not a float number. Please input a number or 'service'")
                    # This will go back to the main loop without crashing the programm
                    # That way the user can try to input another number
                    continue
                
                # Set up the target position
                goal = assignment_2_2022.msg.PlanningGoal()

                goal.target_pose.pose.position.x = x
                goal.target_pose.pose.position.y = y
                goal.target_pose.pose.orientation.w = 1.0
                
                # Send the goal to the server
                client.send_goal(goal)

                # Let 3 seconds to cancel the target. 
                print("press x to cancel the target")
                cancel=select.select ([sys.stdin],  [], [], 3) [0] 
                if cancel:
                    i = sys.stdin.readline().rstrip()
                    if(i=="x"):
                        client.cancel_goal()
                        print("The goal was cancelled")
                       

def main():
    # Initialize the node 
    rospy.init_node("client")

    # Set the pub variable as global so that we can access it from every function
    global pub

    # Publisher to publish the informations velocity and postion with the custom message structure
    pub = rospy.Publisher("/robot_position", output_client, queue_size=10)
   
    # Subscriber to get the informations from /odom
    odom_sub = rospy.Subscriber("/odom", Odometry, publish_infos)

    # Call the client function
    client()


if __name__ == '__main__':
    main()  