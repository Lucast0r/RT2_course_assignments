var searchData=
[
  ['call_5fservice_0',['call_service',['../client_8py.html#aaf0fd819c1bbef4a0c845370302e6f75',1,'client']]],
  ['client_1',['client',['../client_8py.html#ab4ad7f02854ca67edf82407db9acb0a1',1,'client']]],
  ['client_2epy_2',['client.py',['../client_8py.html',1,'']]]
];
