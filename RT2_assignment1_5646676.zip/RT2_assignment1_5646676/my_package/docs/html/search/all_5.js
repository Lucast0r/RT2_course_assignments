var searchData=
[
  ['result_7',['result',['../service_8py.html#a8bda1a8761095d7cd1e6f24a7c4b4bc0',1,'service']]]
];
